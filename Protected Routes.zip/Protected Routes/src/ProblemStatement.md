### Secure the pages of the React app using protected routes.

Use the Navigate element of React Router to navigate user to the Home page if the login status is false.

Learn more about the Navigate element: <a href="https://reactrouter.com/en/main/components/navigate" target="_blank">here</a>

Output:
<img src="https://files.codingninjas.in/protected-routes-26229.gif">
